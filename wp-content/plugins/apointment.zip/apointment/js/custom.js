 

 jQuery(document).ready(function () {
      //alert('data');
      jQuery('.datatable').dataTable();

  });